package main;

import domain.*;
import persistence.PersistenciaManager;
import services.GestorServicios;
import services.RedVial;
import ui.MenuConsola;

/**
 * Punto de entrada del sistema.
 * Intenta cargar datos persistidos; si no existen, inicializa datos de ejemplo.
 */
public class Main {

    public static void main(String[] args) {
        PersistenciaManager persistencia = new PersistenciaManager();

        RedVial redVial;
        GestorServicios gestor;

        System.out.println("\nIniciando sistema...");

        if (persistencia.existenDatosGuardados()) {
            System.out.println("Cargando datos guardados...");
            redVial = persistencia.cargarRedVial();
            gestor  = persistencia.cargarGestor(redVial);

            if (redVial == null || gestor == null) {
                System.out.println("Datos corruptos. Inicializando con datos por defecto...");
                redVial = crearRedVialEjemplo();
                gestor  = crearGestorEjemplo(redVial);
            }
        } else {
            System.out.println("Primera ejecución. Cargando datos de ejemplo...");
            redVial = crearRedVialEjemplo();
            gestor  = crearGestorEjemplo(redVial);
        }

        MenuConsola menu = new MenuConsola(gestor, redVial, persistencia);
        menu.iniciar();
    }

    // ─── Datos de ejemplo ────────────────────────────────────────────────────

    /**
     * Crea una red vial de ejemplo con 5 zonas y varias conexiones.
     * Representa una ciudad pequeña para pruebas académicas.
     */
    private static RedVial crearRedVialEjemplo() {
        RedVial red = new RedVial();

        // Zonas
        Zona centro   = new Zona("Z1", "Centro");
        Zona norte    = new Zona("Z2", "Norte");
        Zona sur      = new Zona("Z3", "Sur");
        Zona oriente  = new Zona("Z4", "Oriente");
        Zona occidente = new Zona("Z5", "Occidente");

        red.agregarZona(centro);
        red.agregarZona(norte);
        red.agregarZona(sur);
        red.agregarZona(oriente);
        red.agregarZona(occidente);

        // Conexiones viales (bidireccionales = dos entradas)
        red.agregarConexion(new ConexionVial(centro,    norte,     4.0));
        red.agregarConexion(new ConexionVial(norte,     centro,    4.0));

        red.agregarConexion(new ConexionVial(centro,    sur,       5.5));
        red.agregarConexion(new ConexionVial(sur,       centro,    5.5));

        red.agregarConexion(new ConexionVial(centro,    oriente,   3.2));
        red.agregarConexion(new ConexionVial(oriente,   centro,    3.2));

        red.agregarConexion(new ConexionVial(centro,    occidente, 6.0));
        red.agregarConexion(new ConexionVial(occidente, centro,    6.0));

        red.agregarConexion(new ConexionVial(norte,     oriente,   2.8));
        red.agregarConexion(new ConexionVial(oriente,   norte,     2.8));

        red.agregarConexion(new ConexionVial(sur,       occidente, 4.5));
        red.agregarConexion(new ConexionVial(occidente, sur,       4.5));

        return red;
    }

    /**
     * Crea el gestor con conductores de ejemplo habilitados para distintos servicios.
     */
    private static GestorServicios crearGestorEjemplo(RedVial red) {
        GestorServicios gestor = new GestorServicios(red);

        // Conductor 1 — estándar y equipaje
        Vehiculo v1 = new Vehiculo("ABC-123", "Chevrolet Spark");
        Conductor c1 = new Conductor("1001", "Carlos Pérez", v1);
        c1.habilitarServicio(TipoServicio.ESTANDAR);
        c1.habilitarServicio(TipoServicio.EQUIPAJE);
        gestor.registrarConductor(c1);

        // Conductor 2 — estándar y mascotas
        Vehiculo v2 = new Vehiculo("DEF-456", "Renault Logan");
        Conductor c2 = new Conductor("1002", "Ana Gómez", v2);
        c2.habilitarServicio(TipoServicio.ESTANDAR);
        c2.habilitarServicio(TipoServicio.MASCOTA);
        gestor.registrarConductor(c2);

        // Conductor 3 — solo estándar
        Vehiculo v3 = new Vehiculo("GHI-789", "Kia Picanto");
        Conductor c3 = new Conductor("1003", "Luis Torres", v3);
        c3.habilitarServicio(TipoServicio.ESTANDAR);
        gestor.registrarConductor(c3);

        // Conductor 4 — todos los servicios
        Vehiculo v4 = new Vehiculo("JKL-321", "Toyota Corolla");
        Conductor c4 = new Conductor("1004", "María Ruiz", v4);
        c4.habilitarServicio(TipoServicio.ESTANDAR);
        c4.habilitarServicio(TipoServicio.EQUIPAJE);
        c4.habilitarServicio(TipoServicio.MASCOTA);
        gestor.registrarConductor(c4);

        return gestor;
    }
}
