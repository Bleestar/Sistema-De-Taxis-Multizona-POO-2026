package domain;

import java.io.Serializable;

/**
 * Representa el vehículo de un conductor.
 * Encapsula placa y modelo.
 */
public class Vehiculo implements Serializable {

    private static final long serialVersionUID = 1L;

    private String placa;
    private String modelo;

    public Vehiculo(String placa, String modelo) {
        this.placa = placa;
        this.modelo = modelo;
    }

    public String getPlaca() {
        return placa;
    }

    public String getModelo() {
        return modelo;
    }

    @Override
    public String toString() {
        return modelo + " [" + placa + "]";
    }
}
