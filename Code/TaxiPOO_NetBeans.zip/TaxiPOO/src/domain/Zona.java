package domain;

import java.io.Serializable;

/**
 * Representa una zona geográfica de la ciudad.
 * Es la unidad básica del grafo de la red vial.
 */
public class Zona implements Serializable {

    private static final long serialVersionUID = 1L;

    private String id;
    private String nombre;

    public Zona(String id, String nombre) {
        this.id = id;
        this.nombre = nombre;
    }

    public String getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    @Override
    public String toString() {
        return "[" + id + "] " + nombre;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Zona)) return false;
        Zona zona = (Zona) o;
        return id.equals(zona.id);
    }

    @Override
    public int hashCode() {
        return id.hashCode();
    }
}
