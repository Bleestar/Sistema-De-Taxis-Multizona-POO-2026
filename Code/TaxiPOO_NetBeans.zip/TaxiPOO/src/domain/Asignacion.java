package domain;

import java.io.Serializable;

/**
 * Registra la asignación de un conductor a una solicitud.
 * Es el objeto que va al historial una vez el servicio cierra.
 */
public class Asignacion implements Serializable {

    private static final long serialVersionUID = 1L;

    private Solicitud solicitud;
    private Conductor conductor;
    private double distanciaKm;
    private double tarifaEstimada;
    private double tiempoEstimadoMinutos;

    public Asignacion(Solicitud solicitud, Conductor conductor,
                      double distanciaKm, double tarifaEstimada, double tiempoEstimadoMinutos) {
        this.solicitud = solicitud;
        this.conductor = conductor;
        this.distanciaKm = distanciaKm;
        this.tarifaEstimada = tarifaEstimada;
        this.tiempoEstimadoMinutos = tiempoEstimadoMinutos;
    }

    public Solicitud getSolicitud() {
        return solicitud;
    }

    public Conductor getConductor() {
        return conductor;
    }

    public double getDistanciaKm() {
        return distanciaKm;
    }

    public double getTarifaEstimada() {
        return tarifaEstimada;
    }

    public double getTiempoEstimadoMinutos() {
        return tiempoEstimadoMinutos;
    }

    @Override
    public String toString() {
        return "Asignación ["
                + "Solicitud #" + solicitud.getId()
                + " | Conductor: " + conductor.getNombre()
                + " | Placa: " + conductor.getVehiculo().getPlaca()
                + " | Distancia: " + distanciaKm + " km"
                + " | Tarifa: $" + String.format("%.0f", tarifaEstimada) + " COP"
                + " | Tiempo estimado: " + String.format("%.0f", tiempoEstimadoMinutos) + " min"
                + " | Estado: " + solicitud.getEstado()
                + "]";
    }
}
