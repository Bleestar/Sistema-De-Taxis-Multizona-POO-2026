package domain;

import java.io.Serializable;

/**
 * Representa una conexión vial entre dos zonas.
 * Puede ser habilitada o deshabilitada (cierre vial).
 * La distancia está en kilómetros.
 */
public class ConexionVial implements Serializable {

    private static final long serialVersionUID = 1L;

    private Zona origen;
    private Zona destino;
    private double distancia;
    private boolean activa;

    public ConexionVial(Zona origen, Zona destino, double distancia) {
        this.origen = origen;
        this.destino = destino;
        this.distancia = distancia;
        this.activa = true;
    }

    public Zona getOrigen() {
        return origen;
    }

    public Zona getDestino() {
        return destino;
    }

    public double getDistancia() {
        return distancia;
    }

    public boolean isActiva() {
        return activa;
    }

    public void setActiva(boolean activa) {
        this.activa = activa;
    }

    @Override
    public String toString() {
        String estado = activa ? "ABIERTA" : "CERRADA";
        return origen.getNombre() + " → " + destino.getNombre()
                + " (" + distancia + " km) [" + estado + "]";
    }
}
