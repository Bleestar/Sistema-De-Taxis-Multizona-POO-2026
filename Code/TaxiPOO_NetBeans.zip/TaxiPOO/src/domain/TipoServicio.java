package domain;

/**
 * Tipos de servicio que soporta la cooperativa.
 * Usar enum evita errores por Strings mal escritos.
 */
public enum TipoServicio {
    ESTANDAR("Taxi estándar"),
    EQUIPAJE("Taxi con baúl/parrilla"),
    MASCOTA("Taxi para mascotas");

    private final String descripcion;

    TipoServicio(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getDescripcion() {
        return descripcion;
    }

    @Override
    public String toString() {
        return descripcion;
    }
}
