package domain;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Representa una solicitud de servicio de taxi.
 * Registra zona de origen, destino, tipo de servicio, estado y fecha/hora.
 */
public class Solicitud implements Serializable {

    private static final long serialVersionUID = 1L;

    private static final DateTimeFormatter FORMATO = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    private String id;
    private Zona origen;
    private Zona destino;
    private TipoServicio tipoServicio;
    private EstadoSolicitud estado;
    private LocalDateTime fechaHoraRegistro;
    private String motivoCancelacion;

    public Solicitud(String id, Zona origen, Zona destino, TipoServicio tipoServicio) {
        this.id = id;
        this.origen = origen;
        this.destino = destino;
        this.tipoServicio = tipoServicio;
        this.estado = EstadoSolicitud.EN_ESPERA;
        this.fechaHoraRegistro = LocalDateTime.now();
    }

    public String getId() {
        return id;
    }

    public Zona getOrigen() {
        return origen;
    }

    public Zona getDestino() {
        return destino;
    }

    public TipoServicio getTipoServicio() {
        return tipoServicio;
    }

    public EstadoSolicitud getEstado() {
        return estado;
    }

    public void setEstado(EstadoSolicitud estado) {
        this.estado = estado;
    }

    public LocalDateTime getFechaHoraRegistro() {
        return fechaHoraRegistro;
    }

    public String getMotivoCancelacion() {
        return motivoCancelacion;
    }

    public void setMotivoCancelacion(String motivoCancelacion) {
        this.motivoCancelacion = motivoCancelacion;
    }

    @Override
    public String toString() {
        return "Solicitud #" + id
                + " | " + tipoServicio.getDescripcion()
                + " | " + origen.getNombre() + " → " + destino.getNombre()
                + " | " + estado
                + " | " + fechaHoraRegistro.format(FORMATO);
    }
}
