package domain;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Representa a un conductor de la cooperativa.
 * Tiene un vehículo asociado y una lista de tipos de servicio habilitados.
 * Puede estar disponible o no disponible (en servicio).
 */
public class Conductor implements Serializable {

    private static final long serialVersionUID = 1L;

    private String identificacion;
    private String nombre;
    private Vehiculo vehiculo;
    private boolean disponible;
    private List<TipoServicio> tiposHabilitados;
    private Zona zonaActual;

    public Conductor(String identificacion, String nombre, Vehiculo vehiculo) {
        this.identificacion = identificacion;
        this.nombre = nombre;
        this.vehiculo = vehiculo;
        this.disponible = true;
        this.tiposHabilitados = new ArrayList<>();
    }

    public void habilitarServicio(TipoServicio tipo) {
        if (!tiposHabilitados.contains(tipo)) {
            tiposHabilitados.add(tipo);
        }
    }

    public boolean estaHabilitadoPara(TipoServicio tipo) {
        return tiposHabilitados.contains(tipo);
    }

    public String getIdentificacion() {
        return identificacion;
    }

    public String getNombre() {
        return nombre;
    }

    public Vehiculo getVehiculo() {
        return vehiculo;
    }

    public boolean isDisponible() {
        return disponible;
    }

    public void setDisponible(boolean disponible) {
        this.disponible = disponible;
    }

    public List<TipoServicio> getTiposHabilitados() {
        return tiposHabilitados;
    }

    public Zona getZonaActual() {
        return zonaActual;
    }

    public void setZonaActual(Zona zonaActual) {
        this.zonaActual = zonaActual;
    }

    @Override
    public String toString() {
        return nombre + " [CC: " + identificacion + "] — " + vehiculo;
    }
}
