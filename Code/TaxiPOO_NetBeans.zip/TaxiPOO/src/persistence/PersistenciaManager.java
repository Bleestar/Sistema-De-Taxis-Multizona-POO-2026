package persistence;

import services.GestorServicios;
import services.RedVial;

import java.io.*;

/**
 * Gestiona la persistencia del sistema mediante serialización de objetos Java.
 * Guarda y carga RedVial y GestorServicios en archivos .dat
 *
 * PRINCIPIO SRP: esta clase solo sabe leer y escribir archivos.
 * No contiene lógica de negocio.
 *
 * Los archivos se guardan en la carpeta "datos/" relativa al directorio de ejecución.
 */
public class PersistenciaManager {

    private static final String CARPETA = "datos/";
    private static final String ARCHIVO_RED = CARPETA + "red_vial.dat";
    private static final String ARCHIVO_GESTOR = CARPETA + "gestor.dat";

    public PersistenciaManager() {
        crearCarpetaSiNoExiste();
    }

    private void crearCarpetaSiNoExiste() {
        File carpeta = new File(CARPETA);
        if (!carpeta.exists()) {
            carpeta.mkdirs();
        }
    }

    // ─── Guardar ────────────────────────────────────────────────────────────

    public void guardarRedVial(RedVial red) {
        try (ObjectOutputStream oos = new ObjectOutputStream(
                new FileOutputStream(ARCHIVO_RED))) {
            oos.writeObject(red);
            System.out.println("  [OK] Red vial guardada.");
        } catch (IOException e) {
            System.err.println("  [ERROR] No se pudo guardar la red vial: " + e.getMessage());
        }
    }

    public void guardarGestor(GestorServicios gestor) {
        try (ObjectOutputStream oos = new ObjectOutputStream(
                new FileOutputStream(ARCHIVO_GESTOR))) {
            oos.writeObject(gestor);
            System.out.println("  [OK] Estado del gestor guardado.");
        } catch (IOException e) {
            System.err.println("  [ERROR] No se pudo guardar el gestor: " + e.getMessage());
        }
    }

    public void guardarTodo(RedVial red, GestorServicios gestor) {
        System.out.println("\nGuardando estado del sistema...");
        guardarRedVial(red);
        guardarGestor(gestor);
    }

    // ─── Cargar ─────────────────────────────────────────────────────────────

    public RedVial cargarRedVial() {
        File archivo = new File(ARCHIVO_RED);
        if (!archivo.exists()) return null;

        try (ObjectInputStream ois = new ObjectInputStream(
                new FileInputStream(archivo))) {
            RedVial red = (RedVial) ois.readObject();
            System.out.println("  [OK] Red vial cargada desde archivo.");
            return red;
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("  [AVISO] No se pudo cargar la red vial: " + e.getMessage());
            return null;
        }
    }

    public GestorServicios cargarGestor(RedVial red) {
        File archivo = new File(ARCHIVO_GESTOR);
        if (!archivo.exists()) return null;

        try (ObjectInputStream ois = new ObjectInputStream(
                new FileInputStream(archivo))) {
            GestorServicios gestor = (GestorServicios) ois.readObject();
            System.out.println("  [OK] Gestor cargado desde archivo.");
            return gestor;
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("  [AVISO] No se pudo cargar el gestor: " + e.getMessage());
            return null;
        }
    }

    public boolean existenDatosGuardados() {
        return new File(ARCHIVO_RED).exists() && new File(ARCHIVO_GESTOR).exists();
    }
}
