package services;

import domain.ConexionVial;
import domain.Zona;
import exceptions.SinConectividadVialException;
import exceptions.ZonaInexistenteException;

import java.io.Serializable;
import java.util.*;

/**
 * Representa la red vial de la ciudad como un grafo dirigido.
 * Permite agregar zonas, conexiones y calcular la ruta más corta habilitada
 * usando el algoritmo de Dijkstra.
 *
 * PRINCIPIO SRP (SOLID): esta clase solo gestiona la topología vial.
 * No sabe nada de conductores ni solicitudes.
 */
public class RedVial implements Serializable {

    private static final long serialVersionUID = 1L;

    private Map<String, Zona> zonas;
    private List<ConexionVial> conexiones;

    public RedVial() {
        this.zonas = new LinkedHashMap<>();
        this.conexiones = new ArrayList<>();
    }

    // ─── Gestión de zonas ───────────────────────────────────────────────────

    public void agregarZona(Zona zona) {
        zonas.put(zona.getId(), zona);
    }

    public Zona buscarZona(String id) throws ZonaInexistenteException {
        Zona zona = zonas.get(id);
        if (zona == null) {
            throw new ZonaInexistenteException("La zona con id '" + id + "' no existe en el sistema.");
        }
        return zona;
    }

    public Collection<Zona> getZonas() {
        return zonas.values();
    }

    // ─── Gestión de conexiones ──────────────────────────────────────────────

    public void agregarConexion(ConexionVial conexion) {
        conexiones.add(conexion);
    }

    public List<ConexionVial> getConexiones() {
        return conexiones;
    }

    /**
     * Habilita o deshabilita una vía entre dos zonas.
     */
    public void modificarEstadoVia(String idOrigen, String idDestino, boolean activa)
            throws ZonaInexistenteException {
        Zona origen = buscarZona(idOrigen);
        Zona destino = buscarZona(idDestino);

        for (ConexionVial c : conexiones) {
            if (c.getOrigen().equals(origen) && c.getDestino().equals(destino)) {
                c.setActiva(activa);
                return;
            }
        }
        throw new ZonaInexistenteException(
                "No existe conexión directa entre " + origen.getNombre()
                        + " y " + destino.getNombre());
    }

    // ─── Cálculo de ruta (Dijkstra) ─────────────────────────────────────────

    /**
     * Calcula la distancia mínima entre dos zonas usando Dijkstra.
     * Solo considera conexiones activas (habilitadas).
     *
     * @return distancia en kilómetros
     * @throws SinConectividadVialException si no hay ruta habilitada
     */
    public double calcularDistanciaMasCorta(Zona origen, Zona destino)
            throws SinConectividadVialException {

        Map<String, Double> distancias = new HashMap<>();
        PriorityQueue<String> cola = new PriorityQueue<>(
                Comparator.comparingDouble(id -> distancias.getOrDefault(id, Double.MAX_VALUE))
        );
        Set<String> visitados = new HashSet<>();

        for (Zona z : zonas.values()) {
            distancias.put(z.getId(), Double.MAX_VALUE);
        }
        distancias.put(origen.getId(), 0.0);
        cola.add(origen.getId());

        while (!cola.isEmpty()) {
            String actualId = cola.poll();

            if (visitados.contains(actualId)) continue;
            visitados.add(actualId);

            if (actualId.equals(destino.getId())) break;

            for (ConexionVial c : conexiones) {
                if (!c.isActiva()) continue;
                if (!c.getOrigen().getId().equals(actualId)) continue;

                String vecinoId = c.getDestino().getId();
                if (visitados.contains(vecinoId)) continue;

                double nuevaDistancia = distancias.get(actualId) + c.getDistancia();
                if (nuevaDistancia < distancias.getOrDefault(vecinoId, Double.MAX_VALUE)) {
                    distancias.put(vecinoId, nuevaDistancia);
                    cola.add(vecinoId);
                }
            }
        }

        double resultado = distancias.getOrDefault(destino.getId(), Double.MAX_VALUE);
        if (resultado == Double.MAX_VALUE) {
            throw new SinConectividadVialException(
                    "No existe ruta habilitada entre '"
                            + origen.getNombre() + "' y '" + destino.getNombre() + "'.");
        }
        return resultado;
    }
}
