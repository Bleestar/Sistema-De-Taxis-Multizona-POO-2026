package services;

import domain.*;
import exceptions.*;
import services.estrategias.EstrategiaTarifa;
import services.estrategias.SelectorTarifa;

import java.io.Serializable;
import java.util.*;

/**
 * Núcleo lógico del sistema.
 * Maneja la cola FIFO de solicitudes, asignación de conductores,
 * validaciones y el historial de asignaciones.
 *
 * PRINCIPIO SRP: solo orquesta servicios. No persiste ni dibuja menús.
 * PRINCIPIO OCP: nuevos tipos de tarifa se agregan via Strategy sin tocar esta clase.
 */
public class GestorServicios implements Serializable {

    private static final long serialVersionUID = 1L;

    // Velocidad promedio en km/h para estimar tiempo de llegada
    private static final double VELOCIDAD_PROMEDIO_KMH = 30.0;

    private final RedVial redVial;
    private final Queue<Solicitud> colaSolicitudes;
    private final List<Conductor> conductores;
    private final List<Asignacion> historial;
    private int contadorSolicitudes;

    public GestorServicios(RedVial redVial) {
        this.redVial = redVial;
        this.colaSolicitudes = new LinkedList<>();
        this.conductores = new ArrayList<>();
        this.historial = new ArrayList<>();
        this.contadorSolicitudes = 0;
    }

    // ─── Gestión de conductores ─────────────────────────────────────────────

    public void registrarConductor(Conductor conductor) {
        conductores.add(conductor);
    }

    public List<Conductor> getConductores() {
        return conductores;
    }

    // ─── Gestión de solicitudes ─────────────────────────────────────────────

    /**
     * Registra una nueva solicitud y la encola en orden FIFO.
     */
    public Solicitud registrarSolicitud(String idOrigen, String idDestino, TipoServicio tipo)
            throws ZonaInexistenteException, SolicitudInvalidaException {

        if (idOrigen == null || idOrigen.isBlank())
            throw new SolicitudInvalidaException("La zona de origen no puede estar vacía.");
        if (idDestino == null || idDestino.isBlank())
            throw new SolicitudInvalidaException("La zona de destino no puede estar vacía.");
        if (idOrigen.equalsIgnoreCase(idDestino))
            throw new SolicitudInvalidaException("El origen y destino no pueden ser la misma zona.");

        Zona origen = redVial.buscarZona(idOrigen);
        Zona destino = redVial.buscarZona(idDestino);

        contadorSolicitudes++;
        String idSolicitud = "SOL-" + String.format("%03d", contadorSolicitudes);
        Solicitud solicitud = new Solicitud(idSolicitud, origen, destino, tipo);
        colaSolicitudes.add(solicitud);
        return solicitud;
    }

    public Queue<Solicitud> getColaSolicitudes() {
        return colaSolicitudes;
    }

    /**
     * Cancela una solicitud en espera con un motivo.
     */
    public void cancelarSolicitud(String idSolicitud, String motivo)
            throws SolicitudInvalidaException {

        Solicitud encontrada = buscarEnCola(idSolicitud);
        if (encontrada == null)
            throw new SolicitudInvalidaException(
                    "No se encontró la solicitud '" + idSolicitud + "' en la cola de espera.");

        colaSolicitudes.remove(encontrada);
        encontrada.setEstado(EstadoSolicitud.CANCELADA);
        encontrada.setMotivoCancelacion(motivo);
        historial.add(new Asignacion(encontrada, null, 0, 0, 0));
    }

    private Solicitud buscarEnCola(String id) {
        for (Solicitud s : colaSolicitudes) {
            if (s.getId().equals(id)) return s;
        }
        return null;
    }

    // ─── Atención y asignación ──────────────────────────────────────────────

    /**
     * Atiende la siguiente solicitud en la cola FIFO.
     * Busca el primer conductor disponible y habilitado con conectividad vial.
     *
     * @return la Asignacion creada con todos los datos del servicio
     */
    public Asignacion atenderSiguienteSolicitud()
            throws SolicitudInvalidaException, ConductorNoHabilitadoException,
            SinConectividadVialException {

        if (colaSolicitudes.isEmpty())
            throw new SolicitudInvalidaException("No hay solicitudes en espera.");

        Solicitud solicitud = colaSolicitudes.peek();

        // Buscar conductor disponible y habilitado para el tipo de servicio
        Conductor conductorSeleccionado = null;
        for (Conductor c : conductores) {
            if (c.isDisponible() && c.estaHabilitadoPara(solicitud.getTipoServicio())) {
                conductorSeleccionado = c;
                break;
            }
        }

        if (conductorSeleccionado == null)
            throw new ConductorNoHabilitadoException(
                    "No hay conductores disponibles habilitados para: "
                            + solicitud.getTipoServicio().getDescripcion());

        // Validar conectividad vial origen → destino
        double distancia = redVial.calcularDistanciaMasCorta(
                solicitud.getOrigen(), solicitud.getDestino());

        // Calcular tarifa con Strategy
        EstrategiaTarifa estrategia = SelectorTarifa.seleccionar(solicitud.getTipoServicio());
        double tarifa = estrategia.calcularPrecio(distancia);

        // Estimar tiempo (distancia / velocidad promedio → en minutos)
        double tiempoMinutos = (distancia / VELOCIDAD_PROMEDIO_KMH) * 60.0;

        // Confirmar asignación
        colaSolicitudes.poll(); // sacar de la cola
        solicitud.setEstado(EstadoSolicitud.EN_ATENCION);
        conductorSeleccionado.setDisponible(false);

        Asignacion asignacion = new Asignacion(
                solicitud, conductorSeleccionado, distancia, tarifa, tiempoMinutos);
        historial.add(asignacion);

        return asignacion;
    }

    // ─── Cierre de servicio ─────────────────────────────────────────────────

    /**
     * Finaliza un servicio en atención: libera al conductor y actualiza estado.
     */
    public void finalizarServicio(String idSolicitud) throws SolicitudInvalidaException {
        Asignacion asignacion = buscarEnHistorial(idSolicitud);
        if (asignacion == null)
            throw new SolicitudInvalidaException(
                    "No se encontró una asignación activa para la solicitud '" + idSolicitud + "'.");

        Solicitud solicitud = asignacion.getSolicitud();
        if (solicitud.getEstado() != EstadoSolicitud.EN_ATENCION)
            throw new SolicitudInvalidaException(
                    "La solicitud '" + idSolicitud + "' no está en atención.");

        solicitud.setEstado(EstadoSolicitud.FINALIZADA);
        if (asignacion.getConductor() != null)
            asignacion.getConductor().setDisponible(true);
    }

    /**
     * Cancela un servicio que ya estaba en atención.
     */
    public void cancelarServicioEnAtencion(String idSolicitud, String motivo)
            throws SolicitudInvalidaException {
        Asignacion asignacion = buscarEnHistorial(idSolicitud);
        if (asignacion == null)
            throw new SolicitudInvalidaException(
                    "No se encontró asignación activa para '" + idSolicitud + "'.");

        Solicitud solicitud = asignacion.getSolicitud();
        if (solicitud.getEstado() != EstadoSolicitud.EN_ATENCION)
            throw new SolicitudInvalidaException(
                    "La solicitud '" + idSolicitud + "' no está en atención.");

        solicitud.setEstado(EstadoSolicitud.CANCELADA);
        solicitud.setMotivoCancelacion(motivo);
        if (asignacion.getConductor() != null)
            asignacion.getConductor().setDisponible(true);
    }

    private Asignacion buscarEnHistorial(String idSolicitud) {
        for (Asignacion a : historial) {
            if (a.getSolicitud().getId().equals(idSolicitud)) return a;
        }
        return null;
    }

    // ─── Historial ──────────────────────────────────────────────────────────

    public List<Asignacion> getHistorial() {
        return historial;
    }

    public int getContadorSolicitudes() {
        return contadorSolicitudes;
    }

    public void setContadorSolicitudes(int contador) {
        this.contadorSolicitudes = contador;
    }
}
