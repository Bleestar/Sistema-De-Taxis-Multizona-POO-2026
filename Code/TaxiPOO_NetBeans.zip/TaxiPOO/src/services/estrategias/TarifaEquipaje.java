package services.estrategias;

/**
 * Tarifa para servicio con baúl/parrilla (equipaje voluminoso).
 * Tiene un recargo adicional por el servicio especial.
 * Costo por km: $1.500 COP
 */
public class TarifaEquipaje implements EstrategiaTarifa {

    private static final double COSTO_POR_KM = 1500.0;
    private static final double RECARGO_EQUIPAJE = 3000.0;

    @Override
    public double calcularPrecio(double distanciaKm) {
        return TARIFA_BASE + RECARGO_EQUIPAJE + (distanciaKm * COSTO_POR_KM);
    }
}
