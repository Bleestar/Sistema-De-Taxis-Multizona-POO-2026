package services.estrategias;

/**
 * Interfaz del patrón Strategy para cálculo de tarifas.
 *
 * PATRÓN STRATEGY — justificación:
 * Cada tipo de servicio tiene una forma distinta de calcular el precio.
 * Strategy permite agregar nuevos tipos de tarifa sin modificar GestorServicios
 * (principio Open/Closed de SOLID).
 */
public interface EstrategiaTarifa {

    double TARIFA_BASE = 5000.0; // COP, igual para todos según enunciado

    /**
     * Calcula la tarifa total del servicio.
     * @param distanciaKm distancia recorrida en kilómetros
     * @return tarifa total en COP
     */
    double calcularPrecio(double distanciaKm);
}
