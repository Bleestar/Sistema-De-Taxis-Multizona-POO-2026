package services.estrategias;

/**
 * Tarifa para servicio de transporte de mascotas.
 * Tiene el recargo más alto por las condiciones especiales del vehículo.
 * Costo por km: $1.400 COP
 */
public class TarifaMascota implements EstrategiaTarifa {

    private static final double COSTO_POR_KM = 1400.0;
    private static final double RECARGO_MASCOTA = 4000.0;

    @Override
    public double calcularPrecio(double distanciaKm) {
        return TARIFA_BASE + RECARGO_MASCOTA + (distanciaKm * COSTO_POR_KM);
    }
}
