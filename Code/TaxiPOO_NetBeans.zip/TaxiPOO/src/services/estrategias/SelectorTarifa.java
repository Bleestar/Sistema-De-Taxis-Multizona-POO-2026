package services.estrategias;

import domain.TipoServicio;

/**
 * Selecciona la estrategia de tarifa correcta según el tipo de servicio.
 *
 * PATRÓN FACTORY METHOD (simple) — justificación:
 * Centraliza la creación de estrategias. Si se agrega un nuevo tipo de servicio,
 * solo se modifica este método, no GestorServicios.
 */
public class SelectorTarifa {

    private SelectorTarifa() {
        // Clase utilitaria, no instanciable
    }

    public static EstrategiaTarifa seleccionar(TipoServicio tipo) {
        switch (tipo) {
            case EQUIPAJE:
                return new TarifaEquipaje();
            case MASCOTA:
                return new TarifaMascota();
            case ESTANDAR:
            default:
                return new TarifaEstandar();
        }
    }
}
