package services.estrategias;

/**
 * Tarifa para servicio de taxi estándar.
 * Costo por km: $1.200 COP
 */
public class TarifaEstandar implements EstrategiaTarifa {

    private static final double COSTO_POR_KM = 1200.0;

    @Override
    public double calcularPrecio(double distanciaKm) {
        return TARIFA_BASE + (distanciaKm * COSTO_POR_KM);
    }
}
