package ui;

import domain.*;
import exceptions.*;
import persistence.PersistenciaManager;
import services.GestorServicios;
import services.RedVial;

import java.util.Scanner;

/**
 * Interfaz de usuario por consola con presentación visual mejorada.
 * Usa códigos ANSI para colores y caracteres Unicode para bordes.
 *
 * PRINCIPIO SRP: solo maneja entrada/salida. Nada de lógica de negocio aquí.
 */
public class MenuConsola {

    // ─── Colores ANSI ────────────────────────────────────────────────────────
    private static final String RESET   = "\u001B[0m";
    private static final String BOLD    = "\u001B[1m";
    private static final String VERDE   = "\u001B[32m";
    private static final String ROJO    = "\u001B[31m";
    private static final String AMARILLO= "\u001B[33m";
    private static final String CIAN    = "\u001B[36m";
    private static final String BLANCO  = "\u001B[37m";
    private static final String AZUL    = "\u001B[34m";

    private final GestorServicios gestor;
    private final RedVial redVial;
    private final PersistenciaManager persistencia;
    private final Scanner scanner;

    public MenuConsola(GestorServicios gestor, RedVial redVial, PersistenciaManager persistencia) {
        this.gestor = gestor;
        this.redVial = redVial;
        this.persistencia = persistencia;
        this.scanner = new Scanner(System.in);
    }

    // ─── Inicio ──────────────────────────────────────────────────────────────

    public void iniciar() {
        limpiarPantalla();
        mostrarBanner();

        boolean ejecutando = true;
        while (ejecutando) {
            mostrarMenuPrincipal();
            int opcion = leerEntero(prompt("Seleccione una opción"));
            ejecutando = ejecutarOpcion(opcion);
        }

        persistencia.guardarTodo(redVial, gestor);
        print("\n" + VERDE + BOLD + "  Sistema cerrado correctamente. ¡Hasta luego!" + RESET + "\n");
    }

    // ─── Banner ──────────────────────────────────────────────────────────────

    private void mostrarBanner() {
        println(CIAN + BOLD);
        println("  ╔══════════════════════════════════════════════════════╗");
        println("  ║        COOPERATIVA DE TAXIS MULTIZONA                ║");
        println("  ║        Sistema de Gestión de Servicios               ║");
        println("  ║        Programación Orientada a Objetos — 2026-I     ║");
        println("  ╚══════════════════════════════════════════════════════╝");
        println(RESET);
    }

    // ─── Menú principal ──────────────────────────────────────────────────────

    private void mostrarMenuPrincipal() {
        println(BOLD + AZUL + "\n  ┌─────────────────────────────────────────────────┐");
        println("  │               MENÚ PRINCIPAL                    │");
        println("  ├─────────────────────────────────────────────────┤" + RESET);
        println("  │  " + CIAN + "1." + RESET + "  Registrar nueva solicitud                    │");
        println("  │  " + CIAN + "2." + RESET + "  Ver solicitudes en espera                    │");
        println("  │  " + CIAN + "3." + RESET + "  Atender siguiente solicitud (FIFO)           │");
        println("  │  " + CIAN + "4." + RESET + "  Cancelar solicitud en espera                 │");
        println("  │  " + CIAN + "5." + RESET + "  Finalizar servicio en atención               │");
        println("  │  " + CIAN + "6." + RESET + "  Cancelar servicio en atención                │");
        println("  │  " + CIAN + "7." + RESET + "  Ver historial de servicios                   │");
        println("  │  " + CIAN + "8." + RESET + "  Ver conductores registrados                  │");
        println("  │  " + CIAN + "9." + RESET + "  Gestión de red vial                          │");
        println(AZUL + "  ├─────────────────────────────────────────────────┤");
        println("  │  " + ROJO + "0." + RESET + "  Guardar y salir                              " + AZUL + "│");
        println("  └─────────────────────────────────────────────────┘" + RESET);
    }

    private boolean ejecutarOpcion(int opcion) {
        switch (opcion) {
            case 1: registrarSolicitud();  break;
            case 2: verColaSolicitudes();  break;
            case 3: atenderSiguiente();    break;
            case 4: cancelarEnEspera();    break;
            case 5: finalizarServicio();   break;
            case 6: cancelarEnAtencion();  break;
            case 7: verHistorial();        break;
            case 8: verConductores();      break;
            case 9: gestionRedVial();      break;
            case 0: return false;
            default: msgError("Opción no válida. Elija entre 0 y 9.");
        }
        return true;
    }

    // ─── Opción 1: Registrar solicitud ───────────────────────────────────────

    private void registrarSolicitud() {
        encabezado("REGISTRAR NUEVA SOLICITUD");
        mostrarZonas();

        String idOrigen = pedirZonaValida("  Ingrese ID zona de ORIGEN : ");
        if (idOrigen == null) return;

        String idDestino = pedirZonaValida("  Ingrese ID zona de DESTINO: ");
        if (idDestino == null) return;

        if (idOrigen.equalsIgnoreCase(idDestino)) {
            msgError("El origen y el destino no pueden ser la misma zona.");
            return;
        }

        TipoServicio tipo = seleccionarTipoServicio();
        if (tipo == null) return;

        try {
            Solicitud s = gestor.registrarSolicitud(idOrigen, idDestino, tipo);
            println("\n" + VERDE + BOLD + "  ✔  Solicitud registrada exitosamente" + RESET);
            separador();
            println("  " + BOLD + "ID        : " + RESET + s.getId());
            println("  " + BOLD + "Tipo      : " + RESET + s.getTipoServicio().getDescripcion());
            println("  " + BOLD + "Origen    : " + RESET + s.getOrigen().getNombre());
            println("  " + BOLD + "Destino   : " + RESET + s.getDestino().getNombre());
            println("  " + BOLD + "Estado    : " + RESET + AMARILLO + s.getEstado() + RESET);
            separador();
        } catch (ZonaInexistenteException | SolicitudInvalidaException e) {
            msgError(e.getMessage());
        }
    }

    private String pedirZonaValida(String mensaje) {
        int intentos = 0;
        final int MAX = 3;
        while (intentos < MAX) {
            String id = leerTexto(mensaje);
            if (id.isEmpty()) {
                msgError("El ID de zona no puede estar vacío.");
                intentos++;
                continue;
            }
            boolean existe = redVial.getZonas().stream()
                    .anyMatch(z -> z.getId().equalsIgnoreCase(id));
            if (existe) return id.toUpperCase();

            intentos++;
            msgError("La zona '" + id + "' no existe. Intento " + intentos + "/" + MAX + ".");
            if (intentos < MAX) mostrarZonas();
            else msgAdvertencia("Demasiados intentos. Operación cancelada.");
        }
        return null;
    }

    private TipoServicio seleccionarTipoServicio() {
        int intentos = 0;
        final int MAX = 3;
        while (intentos < MAX) {
            println("\n" + BOLD + "  Tipos de servicio disponibles:" + RESET);
            println("  " + CIAN + "1." + RESET + "  Taxi estándar");
            println("  " + CIAN + "2." + RESET + "  Taxi con baúl / parrilla (equipaje voluminoso)");
            println("  " + CIAN + "3." + RESET + "  Taxi para transporte de mascotas");
            int op = leerEntero(prompt("Seleccione tipo (1-3)"));
            switch (op) {
                case 1: return TipoServicio.ESTANDAR;
                case 2: return TipoServicio.EQUIPAJE;
                case 3: return TipoServicio.MASCOTA;
                default:
                    intentos++;
                    msgError("Opción inválida. Debe ser 1, 2 o 3. Intento " + intentos + "/" + MAX + ".");
                    if (intentos == MAX) msgAdvertencia("Demasiados intentos. Operación cancelada.");
            }
        }
        return null;
    }

    // ─── Opción 2: Ver cola ──────────────────────────────────────────────────

    private void verColaSolicitudes() {
        encabezado("SOLICITUDES EN ESPERA");
        if (gestor.getColaSolicitudes().isEmpty()) {
            msgAdvertencia("No hay solicitudes en espera.");
            return;
        }
        println(BOLD + "  #   ID         Tipo                  Origen → Destino         Estado" + RESET);
        separador();
        int i = 1;
        for (Solicitud s : gestor.getColaSolicitudes()) {
            println(String.format("  %-3d %-10s %-22s %-10s → %-10s %s%s%s",
                    i++,
                    s.getId(),
                    s.getTipoServicio().getDescripcion(),
                    s.getOrigen().getNombre(),
                    s.getDestino().getNombre(),
                    AMARILLO, s.getEstado(), RESET));
        }
        separador();
    }

    // ─── Opción 3: Atender siguiente ─────────────────────────────────────────

    private void atenderSiguiente() {
        encabezado("ATENDER SIGUIENTE SOLICITUD (FIFO)");
        try {
            Asignacion a = gestor.atenderSiguienteSolicitud();
            println(VERDE + BOLD + "\n  ✔  SERVICIO ASIGNADO CORRECTAMENTE" + RESET);
            separador();
            fila("Solicitud",      "#" + a.getSolicitud().getId());
            fila("Conductor",      a.getConductor().getNombre());
            fila("Identificación", a.getConductor().getIdentificacion());
            fila("Placa",          a.getConductor().getVehiculo().getPlaca());
            fila("Vehículo",       a.getConductor().getVehiculo().getModelo());
            fila("Origen",         a.getSolicitud().getOrigen().getNombre());
            fila("Destino",        a.getSolicitud().getDestino().getNombre());
            fila("Distancia",      String.format("%.2f km", a.getDistanciaKm()));
            println("  " + BOLD + String.format("%-18s", "Tarifa estimada") + ": "
                    + VERDE + BOLD + String.format("$%,.0f COP", a.getTarifaEstimada()) + RESET);
            println("  " + BOLD + String.format("%-18s", "Tiempo estimado") + ": "
                    + CIAN + String.format("%.0f minutos", a.getTiempoEstimadoMinutos()) + RESET);
            separador();
        } catch (SolicitudInvalidaException | ConductorNoHabilitadoException
                 | SinConectividadVialException e) {
            msgError(e.getMessage());
        }
    }

    // ─── Opción 4: Cancelar en espera ────────────────────────────────────────

    private void cancelarEnEspera() {
        encabezado("CANCELAR SOLICITUD EN ESPERA");
        verColaSolicitudes();
        if (gestor.getColaSolicitudes().isEmpty()) return;

        String id     = leerTexto(prompt("ID de la solicitud a cancelar"));
        String motivo = leerTexto(prompt("Motivo de cancelación"));

        if (motivo.isBlank()) {
            msgError("Debe ingresar un motivo de cancelación.");
            return;
        }
        try {
            gestor.cancelarSolicitud(id, motivo);
            msgOk("Solicitud " + id + " cancelada correctamente.");
        } catch (SolicitudInvalidaException e) {
            msgError(e.getMessage());
        }
    }

    // ─── Opción 5: Finalizar servicio ─────────────────────────────────────────

    private void finalizarServicio() {
        encabezado("FINALIZAR SERVICIO");
        String id = leerTexto(prompt("ID de la solicitud a finalizar"));
        try {
            gestor.finalizarServicio(id);
            msgOk("Servicio " + id + " finalizado exitosamente. Conductor liberado.");
        } catch (SolicitudInvalidaException e) {
            msgError(e.getMessage());
        }
    }

    // ─── Opción 6: Cancelar en atención ──────────────────────────────────────

    private void cancelarEnAtencion() {
        encabezado("CANCELAR SERVICIO EN ATENCIÓN");
        String id     = leerTexto(prompt("ID de la solicitud"));
        String motivo = leerTexto(prompt("Motivo de cancelación"));
        if (motivo.isBlank()) {
            msgError("Debe ingresar un motivo de cancelación.");
            return;
        }
        try {
            gestor.cancelarServicioEnAtencion(id, motivo);
            msgOk("Servicio " + id + " cancelado. Conductor liberado.");
        } catch (SolicitudInvalidaException e) {
            msgError(e.getMessage());
        }
    }

    // ─── Opción 7: Historial ──────────────────────────────────────────────────

    private void verHistorial() {
        encabezado("HISTORIAL DE SERVICIOS");
        if (gestor.getHistorial().isEmpty()) {
            msgAdvertencia("El historial está vacío.");
            return;
        }
        println(BOLD + "  ID         Conductor          Distancia   Tarifa           Estado" + RESET);
        separador();
        for (Asignacion a : gestor.getHistorial()) {
            String conductor = a.getConductor() != null ? a.getConductor().getNombre() : "—";
            String estado = a.getSolicitud().getEstado().toString();
            String colorEstado = estado.equals("FINALIZADA") ? VERDE
                    : estado.equals("CANCELADA") ? ROJO : AMARILLO;
            println(String.format("  %-10s %-18s %-11s %-16s %s%s%s",
                    "#" + a.getSolicitud().getId(),
                    conductor,
                    a.getDistanciaKm() > 0 ? String.format("%.2f km", a.getDistanciaKm()) : "—",
                    a.getTarifaEstimada() > 0 ? String.format("$%,.0f COP", a.getTarifaEstimada()) : "—",
                    colorEstado, estado, RESET));
        }
        separador();
    }

    // ─── Opción 8: Conductores ────────────────────────────────────────────────

    private void verConductores() {
        encabezado("CONDUCTORES REGISTRADOS");
        if (gestor.getConductores().isEmpty()) {
            msgAdvertencia("No hay conductores registrados.");
            return;
        }
        for (Conductor c : gestor.getConductores()) {
            boolean disp = c.isDisponible();
            String colorEstado = disp ? VERDE : AMARILLO;
            String estado = disp ? "DISPONIBLE" : "EN SERVICIO";
            separador();
            println("  " + BOLD + c.getNombre() + RESET
                    + "   " + colorEstado + BOLD + "● " + estado + RESET);
            fila("CC",           c.getIdentificacion());
            fila("Vehículo",     c.getVehiculo().getModelo());
            fila("Placa",        c.getVehiculo().getPlaca());
            fila("Habilitado",   c.getTiposHabilitados().toString());
        }
        separador();
    }

    // ─── Opción 9: Red vial ───────────────────────────────────────────────────

    private void gestionRedVial() {
        encabezado("GESTIÓN DE RED VIAL");
        println("  " + CIAN + "1." + RESET + "  Ver todas las conexiones");
        println("  " + CIAN + "2." + RESET + "  Reportar cierre vial");
        println("  " + CIAN + "3." + RESET + "  Reportar apertura vial");
        int op = leerEntero(prompt("Opción"));

        switch (op) {
            case 1:
                println("\n" + BOLD + "  Conexiones viales registradas:" + RESET);
                separador();
                for (ConexionVial c : redVial.getConexiones()) {
                    String color = c.isActiva() ? VERDE : ROJO;
                    String estado = c.isActiva() ? "ABIERTA" : "CERRADA";
                    println("  " + c.getOrigen().getNombre()
                            + " → " + c.getDestino().getNombre()
                            + "  (" + c.getDistancia() + " km)  "
                            + color + BOLD + "[" + estado + "]" + RESET);
                }
                separador();
                break;
            case 2:
            case 3:
                mostrarZonas();
                String orig = pedirZonaValida("  ID zona origen : ");
                if (orig == null) return;
                String dest = pedirZonaValida("  ID zona destino: ");
                if (dest == null) return;
                boolean activar = (op == 3);
                try {
                    redVial.modificarEstadoVia(orig, dest, activar);
                    msgOk("Vía " + orig + " → " + dest
                            + (activar ? " abierta." : " cerrada."));
                } catch (ZonaInexistenteException e) {
                    msgError(e.getMessage());
                }
                break;
            default:
                msgError("Opción no válida.");
        }
    }

    // ─── Utilidades de presentación ───────────────────────────────────────────

    private void encabezado(String titulo) {
        int ancho = 54;
        String linea = "─".repeat(ancho);
        int espacios = (ancho - titulo.length()) / 2;
        String centrado = " ".repeat(Math.max(0, espacios)) + titulo;
        println("\n" + BOLD + CIAN + "  ┌" + linea + "┐");
        println("  │" + centrado + " ".repeat(Math.max(0, ancho - centrado.length())) + "│");
        println("  └" + linea + "┘" + RESET);
    }

    private void separador() {
        println(AZUL + "  " + "─".repeat(54) + RESET);
    }

    private void fila(String etiqueta, String valor) {
        println("  " + BOLD + String.format("%-18s", etiqueta) + ": " + RESET + valor);
    }

    private String prompt(String mensaje) {
        return "\n  " + BOLD + BLANCO + "▶  " + mensaje + ": " + RESET;
    }

    private void msgOk(String msg) {
        println("\n  " + VERDE + BOLD + "✔  " + msg + RESET);
    }

    private void msgError(String msg) {
        println("\n  " + ROJO + BOLD + "✖  " + msg + RESET);
    }

    private void msgAdvertencia(String msg) {
        println("\n  " + AMARILLO + BOLD + "⚠  " + msg + RESET);
    }

    private void mostrarZonas() {
        println("\n" + BOLD + "  Zonas disponibles:" + RESET);
        for (Zona z : redVial.getZonas()) {
            println("  " + CIAN + "  [" + z.getId() + "]" + RESET + "  " + z.getNombre());
        }
    }

    private void limpiarPantalla() {
        System.out.print("\033[H\033[2J");
        System.out.flush();
    }

    private int leerEntero(String mensaje) {
        System.out.print(mensaje);
        String entrada = scanner.nextLine().trim();
        try {
            return Integer.parseInt(entrada);
        } catch (NumberFormatException e) {
            if (!entrada.isEmpty())
                msgError("'" + entrada + "' no es un número válido.");
            return -1;
        }
    }

    private String leerTexto(String mensaje) {
        System.out.print(mensaje);
        return scanner.nextLine().trim();
    }

    private void println(String texto) {
        System.out.println(texto);
    }

    private void print(String texto) {
        System.out.print(texto);
    }
}
