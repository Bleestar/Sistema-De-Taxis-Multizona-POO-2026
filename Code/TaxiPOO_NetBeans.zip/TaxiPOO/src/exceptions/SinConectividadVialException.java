package exceptions;

/**
 * Se lanza cuando no existe ruta habilitada entre dos zonas.
 */
public class SinConectividadVialException extends Exception {
    public SinConectividadVialException(String mensaje) {
        super(mensaje);
    }
}
