package exceptions;

/**
 * Se lanza cuando ningún conductor disponible está habilitado
 * para el tipo de servicio solicitado.
 */
public class ConductorNoHabilitadoException extends Exception {
    public ConductorNoHabilitadoException(String mensaje) {
        super(mensaje);
    }
}
