package exceptions;

/**
 * Se lanza cuando se referencia una zona que no existe en el sistema.
 */
public class ZonaInexistenteException extends Exception {
    public ZonaInexistenteException(String mensaje) {
        super(mensaje);
    }
}
