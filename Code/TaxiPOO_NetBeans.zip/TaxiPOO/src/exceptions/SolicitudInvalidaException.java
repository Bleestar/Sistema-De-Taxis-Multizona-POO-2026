package exceptions;

/**
 * Se lanza cuando una solicitud tiene datos inválidos o incompletos,
 * o cuando se intenta operar sobre una solicitud en estado incorrecto.
 */
public class SolicitudInvalidaException extends Exception {
    public SolicitudInvalidaException(String mensaje) {
        super(mensaje);
    }
}
